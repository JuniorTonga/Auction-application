# AuctionApp
## This project is intended to implement the concurrent programming concepts in java.

- We got two type of client(an administrator and a lambda client) that can be simultenously connected to the same server.

- For the admin, the connection password is :FSG2021.

## Each type of client got a bunch of commands. After application lauching just follow the instructions in the terminal

## Launch ServerProcess before and after that launch ClientProcess respectively located in server and client package in src project package.

